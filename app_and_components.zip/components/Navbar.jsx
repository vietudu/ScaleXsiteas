export default function Navbar(){
  return(
    <nav className='p-4 shadow bg-white'>
      ScaleXsites Navbar
    </nav>
  );
}